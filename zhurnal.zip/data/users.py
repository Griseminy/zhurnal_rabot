import datetime

import sqlalchemy

from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'users'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    surname = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    age = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    position = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    speciality = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    address = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    email = sqlalchemy.Column(sqlalchemy.String, unique=True, nullable=True)
    hashed_password = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    modified_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                      default=datetime.datetime.now)

    def __init__(self, __tablename__, id, surname, name, age, position, speciality, address,
                 email, hashed_password, modified_date):
        self.__tablename__ = __tablename__

        self.id = id
        self.surname = surname
        self.name = name
        self.age = age
        self.position = position
        self.speciality = speciality
        self.address = address
        self.email = email
        self.hashed_password = hashed_password
        self.modified_date = modified_date


    def __repr__(self):
        return f"<Colonist> {self.id} {self.surname} {self.name}"
